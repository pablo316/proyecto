<?php

namespace constructora\Events;

abstract class Event
{
    //
}
