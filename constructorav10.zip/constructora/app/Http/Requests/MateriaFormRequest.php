<?php

namespace constructora\Http\Requests;

use constructora\Http\Requests\Request;

class MateriaFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
        'pro_rut'=>'max:20|required', 
        'mat_nombre'=>'max:20|required',
        'mat_marca'=>'max:20|required',
        'mat_stockini'=>'integer|max:10000|required', 
        'mat_stockmin'=>'integer|max:10000|required',  
        'mat_fechaad'=>'date|max:20|required',  
        'mat_precio'=>'integer|max:10000000000|required',
        ];
    }
}
