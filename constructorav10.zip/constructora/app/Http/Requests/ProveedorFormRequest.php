<?php

namespace constructora\Http\Requests;

use constructora\Http\Requests\Request;

class ProveedorFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'pro_rut'=>'integer|required|max:99999999|min:10000000|unique:proveedor',
            'pro_dv'=>'max:1|min:1|required',
            'pro_nombre'=>'max:20|required',
            'pro_direccion'=>'max:20|required',
            'pro_telefono'=>'integer|max:1000000|required',
        ];
    }
}
